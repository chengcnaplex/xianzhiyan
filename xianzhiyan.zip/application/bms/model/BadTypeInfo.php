<?php
namespace app\bms\model;

use think\Model;
class BadTypeInfo extends Model{

    protected $table = 'xzy_badtype_info';

}
