<?php
namespace app\bms\model;

use think\Model;
class AdminLevelModel extends Model{

    protected $table = 'xzy_admin_level_detail';

}
