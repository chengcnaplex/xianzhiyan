<?php
namespace app\bms\model;

use think\Model;
class BadBehaviorInfo extends Model{

    protected $table = 'xzy_badbehavior_info';

}
