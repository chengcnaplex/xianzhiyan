<?php
namespace app\bms\controller;

use think\Controller;

class BadBehavior extends Controller
{
    public function index()
    {
        return "1";
    }
}
